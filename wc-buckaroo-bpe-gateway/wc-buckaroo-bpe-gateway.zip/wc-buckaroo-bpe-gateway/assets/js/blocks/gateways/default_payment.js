const DefaultPayment = () => {
	return;
};

export default DefaultPayment;
